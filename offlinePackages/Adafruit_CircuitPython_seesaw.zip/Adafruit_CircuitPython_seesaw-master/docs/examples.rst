Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/seesaw_simpletest.py
    :caption: examples/seesaw_simpletest.py
    :linenos:

Other Examples
---------------

Here are some other examples using the Seesaw library

.. literalinclude:: ../examples/seesaw_crickit_test.py
    :caption: examples/seesaw_crickit_test.py
    :linenos:

.. literalinclude:: ../examples/seesaw_joy_featherwing.py
    :caption: examples/seesaw_joy_featherwing.py
    :linenos:

.. literalinclude:: ../examples/seesaw_soil_simpletest.py
    :caption: examples/seesaw_soil_simpletest.py
    :linenos:

.. literalinclude:: ../examples/seesaw_minitft_featherwing.py
    :caption: examples/seesaw_minitft_featherwing.py
    :linenos:
