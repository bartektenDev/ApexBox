
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_seesaw
    :members:

.. automodule:: adafruit_seesaw.seesaw
   :members:

.. automodule:: adafruit_seesaw.crickit
   :members:

.. automodule:: adafruit_seesaw.analoginput
   :members:

.. automodule:: adafruit_seesaw.digitalio
   :members:

.. automodule:: adafruit_seesaw.__init__
   :members:

.. automodule:: adafruit_seesaw.keypad
   :members:

.. automodule:: adafruit_seesaw.neopixel
   :members:

.. automodule:: adafruit_seesaw.pwmout
   :members:

.. automodule:: adafruit_seesaw.robohat
   :members:

.. automodule:: adafruit_seesaw.samd09
   :members:

.. automodule:: adafruit_seesaw.tftshield18
   :members:

